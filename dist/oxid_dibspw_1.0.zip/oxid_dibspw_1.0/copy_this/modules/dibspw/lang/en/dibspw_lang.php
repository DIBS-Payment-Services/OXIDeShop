$sLangName  = "English";
// -------------------------------
// RESOURCE IDENTITFIER = STRING
// -------------------------------
$aLang = array(
'charset'                                  => 'ISO-8859-15',
'DIBSPW_MERCHANT_ID'                         => 'Merchant ID'
);

/*
[{ oxmultilang ident="GENERAL_YOUWANTTODELETE" }]
*/
