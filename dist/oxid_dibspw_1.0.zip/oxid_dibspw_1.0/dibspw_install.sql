INSERT INTO  `oxpayments` (
`OXID` ,
`OXACTIVE` ,
`OXDESC` ,
`OXADDSUM` ,
`OXADDSUMTYPE` ,
`OXADDSUMRULES` ,
`OXFROMBONI` ,
`OXFROMAMOUNT` ,
`OXTOAMOUNT` ,
`OXVALDESC` ,
`OXCHECKED` ,
`OXDESC_1` ,
`OXVALDESC_1` ,
`OXDESC_2` ,
`OXVALDESC_2` ,
`OXDESC_3` ,
`OXVALDESC_3` ,
`OXLONGDESC` ,
`OXLONGDESC_1` ,
`OXLONGDESC_2` ,
`OXLONGDESC_3` ,
`OXSORT` ,
`OXTSPAYMENTID`
)
VALUES (
'dibspw',  '1',  'DIBS Payment Window',  '0',  'abs',  '0',  '0',  '0',  '0',  '',  '1',  '',  'DIBS Payment Window',  '',  '',  '',  '',  '',  '',  '',  '',  '0',  ''
);